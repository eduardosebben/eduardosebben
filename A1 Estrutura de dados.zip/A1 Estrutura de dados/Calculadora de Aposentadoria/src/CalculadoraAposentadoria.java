import java.util.Scanner;

public class CalculadoraAposentadoria {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a sua idade: ");
        int idade = scanner.nextInt();

        System.out.print("Digite o seu sexo (M/F): ");
        char sexo = scanner.next().charAt(0);

        System.out.print("Digite o número de anos de contribuição: ");
        int anosContribuicao = scanner.nextInt();

        boolean podeAposentar = false;
        int anosFaltando = 0;

        if (sexo == 'M' || sexo == 'm') {
            if (idade >= 65 || anosContribuicao >= 35) {
                podeAposentar = true;
            } else {
                anosFaltando = Math.max(65 - idade, 35 - anosContribuicao);
            }
        } else if (sexo == 'F' || sexo == 'f') {
            if (idade >= 60 || anosContribuicao >= 30) {
                podeAposentar = true;
            } else {
                anosFaltando = Math.max(60 - idade, 30 - anosContribuicao);
            }
        }

        if (podeAposentar) {
            System.out.println("Você já pode se aposentar!");
        } else {
            System.out.println("Você ainda precisa de " + anosFaltando + " anos para se aposentar.");
        }
    }
}
