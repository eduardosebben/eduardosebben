import java.util.Scanner;

public class CalculadoraDesconto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor do produto: ");
        double valorProduto = scanner.nextDouble();

        System.out.print("Digite a porcentagem de desconto: ");
        double descontoPercentual = scanner.nextDouble();

        double valorDesconto = valorProduto * descontoPercentual / 100;
        double valorFinal = valorProduto - valorDesconto;

        System.out.println("Valor do desconto: " + valorDesconto);
        System.out.println("Preço final após o desconto: " + valorFinal);
    }
}
