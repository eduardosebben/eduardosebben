import java.util.Scanner;

public class CircuitoResistencias {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor da resistência R1: ");
        double r1 = scanner.nextDouble();

        System.out.print("Digite o valor da resistência R2: ");
        double r2 = scanner.nextDouble();

        System.out.print("Digite o valor da resistência R3: ");
        double r3 = scanner.nextDouble();

        System.out.print("Digite o valor da resistência R4: ");
        double r4 = scanner.nextDouble();

        double resistenciaEquivalente = r1 + r2 + r3 + r4;
        double maiorResistencia = Math.max(Math.max(r1, r2), Math.max(r3, r4));
        double menorResistencia = Math.min(Math.min(r1, r2), Math.min(r3, r4));

        System.out.println("Resistência equivalente: " + resistenciaEquivalente);
        System.out.println("Maior resistência: " + maiorResistencia);
        System.out.println("Menor resistência: " + menorResistencia);
    }
}
