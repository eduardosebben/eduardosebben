import javax.swing.JOptionPane;

public class SistemaLogin {
    public static void main(String[] args) {
        String usuario = "java8";
        String senha = "java8";

        for (int i = 0; i < 3; i++) {
            String login = JOptionPane.showInputDialog("Digite seu login:");
            String password = JOptionPane.showInputDialog("Digite sua senha:");

            if (login.equals(usuario) && password.equals(senha)) {
                JOptionPane.showMessageDialog(null, "Login bem-sucedido!");
                return;
            } else {
                JOptionPane.showMessageDialog(null, "Login ou senha incorretos! Tentativa " + (i+1) + " de 3.");
            }
        }

        JOptionPane.showMessageDialog(null, "Número de tentativas excedido.");
    }
}
